<?php $__env->startSection('content'); ?>
  <div class="d-flex justify-content-center align-items-center vh-100 ">
    <div class="d-flex align-items-center bg-white p-4 rounded bg-danger">
      <div style="margin-right: 20px;">
        <a class="navbar-brand navbar-brand-autodark">
          <img src="<?php echo e(asset('static/logo.png')); ?>" width="110" height="84"
            alt="Tabler" class="navbar-brand-image" style="height: 80%">
        </a>
      </div>
      <div class="card-md" style="width: 600px;">
        <div class="card-body">
          <h2 class="h2 text-center mb-4">
            Ingrese a su cuenta
          </h2>
          <form action="<?php echo e(route('login')); ?>" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="email" class="form-label">
                Dirección de correo electrónico
              </label>
              <input type="email" name="email" id="email"
                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="tu@correo electrónico.com" autocomplete="off"
                value="<?php echo e(old('email')); ?>">

              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-2">
              <label for="password" class="form-label">
                Contraseña
              </label>
              <div class="input-group input-group-flat">
                <input type="password" name="password" id="password"
                  class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                  placeholder="Tu contraseña" autocomplete="off">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback">
                    <?php echo e($message); ?>

                  </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="mb-2">
              <label for="remember" class="form-check">
                <input type="checkbox" id="remember" name="remember"
                  class="form-check-input" />
                <span class="form-check-label">Recuérdame en este
                  dispositivo</span>
              </label>
            </div>
            <div class="form-footer">
              <button type="submit" class="btn btn-primary w-100">
                Iniciar sesión
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wilson/Documentos/Softec/inventario/resources/views/auth/login.blade.php ENDPATH**/ ?>