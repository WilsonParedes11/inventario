<div class="d-flex justify-content-center">
    <div wire:loading class="spinner-border text-muted" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
