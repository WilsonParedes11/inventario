 <nav class="nav nav-borders">
     <a class="nav-link " href="{{ route('profile.edit') }}">Perfil</a>
     <a class="nav-link active " href="{{ route('profile.settings') }}">Ajustes</a>
     <a class="nav-link " href="{{ route('profile.store.settings') }}">Tienda</a>
 </nav>
