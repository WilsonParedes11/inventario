<?php

namespace App\Http\Controllers\Quotation;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class QuotationSalesController extends Controller
{
    //
}
